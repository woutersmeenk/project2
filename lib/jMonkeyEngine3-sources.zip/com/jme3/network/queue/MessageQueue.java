package com.jme3.network.queue;

import com.jme3.network.message.Message;
import java.util.concurrent.ConcurrentLinkedQueue;

public class MessageQueue extends ConcurrentLinkedQueue<Message> {
    
}
